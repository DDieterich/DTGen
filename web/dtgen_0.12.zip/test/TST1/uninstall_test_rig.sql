
prompt
prompt === Un-Install DTGen Test Rig ===

drop PACKAGE tr_btt_str;
drop PACKAGE tr_btt_dtm;
drop PACKAGE tr_btt_num;
drop PACKAGE trc;
