
DTGen Tiers Demonstration
   Developed by DMSTEX (http://dmstex.com)


Files and Directories:
----------------------
tiers_demo.odt - Demonstration Documentation (OpenOffice format)
tiers_demo.pdf - Demonstration Documentation (Acrobat format)
e1.sql         - Exercise #1: Simple Mid-Tier
e2.sql         - Exercise #2: Materialized Views
e3.sql         - Exercise #3: User Security
e4.sql         - Exercise #4: Global Locks
e4a.sql        - Exercise #4: Global Locks Auxillary


Exercises that Modify Data
--------------------------
There are 2 exercises that modify data in the database.  These exercises cannot be re-run without resetting the database.
  -) e1.sql
  -) e3.sql
