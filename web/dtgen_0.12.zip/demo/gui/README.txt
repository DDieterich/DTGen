
DTGen Graphical User Interface (GUI) Demonstration
   Developed by DMSTEX (http://dmstex.com)


Files and Directories:
----------------------
cleanup.sql        - Removes GUI Demonstration from APEX
gui_demo.odt       - Demonstration Documentation (OpenOffice format)
gui_demo.pdf       - Demonstration Documentation (Acrobat format)
e1.sql             - Exercise #1: Default Maintenance Forms
setup.sql          - Exercise Setup, Creates Workspace and APEX User

Exercises that Modify Data
--------------------------
There are 2 exercises that modify data in the database.  These exercises cannot be re-run without resetting the database.
  -) e1.sql
  -) Exercise #2
