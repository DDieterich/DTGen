
REM
REM Drop Demonstration Schema Users
REM (Must be run as the "system" or "sys as sysdba" user)
REM

spool drop_demo_users
set define '&'
set verify off

REM Initialize Variables
REM
@vars

REM Configure SQL*Plus
REM
WHENEVER SQLERROR CONTINUE
WHENEVER OSERROR CONTINUE
set trimspool on
set serveroutput on format wrapped
set define on

prompt
prompt This will remove the following roles and users from the database:
prompt
prompt   -) &USR_NAME. user
prompt   -) &MT_NAME. user
prompt   -) &DB_NAME. user
prompt   -) DEMO3_app role
prompt   -) DEMO3_dml role
prompt
prompt Press ENTER to continue
accept junk

drop user &USR_NAME. cascade;
drop user &MT_NAME. cascade;
drop user &DB_NAME. cascade;

drop role DEMO3_app;
drop role DEMO3_dml;

prompt If the above statement failed with "user that is currently connected", then
prompt    re-run this script
prompt

spool off

exit
