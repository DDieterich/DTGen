
REM
REM Variable Declarations
REM (Use @vars like an INCLUDE file)
REM

define TSPACE = users               -- Default Tablespace
define TNS_ALIAS = @XE2             -- TNS Alias (must include @ sign)
define OWNERNAME = dtgen            -- DTGen Generator Schema Username
define OWNERPASS = dtgen            -- DTGen Generator Schema Password
define DB_NAME = dtgen_db_demo      -- Database DEMO Schema Username
define DB_PASS = dtgen              -- Database DEMO Schema Password
define MT_NAME = dtgen_mt_demo      -- Mid-Tier DEMO Schema Username
define MT_PASS = dtgen              -- Mid-Tier DEMO Schema Password
define USR_NAME = dtgen_usr_demo    -- DEMO User Username
define USR_PASS = dtgen             -- DEMO User Password
