
DTGen ASOF Demonstration
   Developed by DMSTEX (http://dmstex.com)


Files and Directories:
----------------------
asof_demo.odt - Demonstration Documentation (OpenOffice format)
asof_demo.pdf - Demonstration Documentation (Acrobat format)
data.ods      - Exercise #1: Data Load Spreadsheet (OpenOffice)
e1.sql        - Exercise #1: Entity Based History and Audit
e2.sql        - Exercise #2: EFF vs. LOG Table Types
e3.sql        - Exercise #3: Point-in-Time ASOF Views
e4.sql        - Exercise #4: Audited POP Functions
e5.sql        - Exercise #5: All Instances View
e6.sql        - Exercise #6: Transportable ASOF Data


Exercises that Modify Data
--------------------------
There are 4 exercises that modify data in the database.  These exercises cannot be re-run without resetting the database.
  -) e1.sql
  -) e4.sql
  -) e5.sql
  -) e6.sql
