
DTGen "src" (Source) README File
   Developed by DMSTEX (http://dmstex.com)


Files and Directories:
----------------------
comp.sql           - Used by install.sql to create the DTGen packages
dtgen_util.pkb     - Used by comp.sql to create the DTGen Utility package body
dtgen_util.pks     - Used by comp.sql to create the DTGen Utility package spec
generate.pkb       - Used by comp.sql to create the DTGen Generate package body
generate.pks       - Used by comp.sql to create the DTGen Generate package spec
install.sql        - Installs DTGen Schema. Run as "sys" user.
install_db.sql     - Used by install.sql to create DTGen's Database Objects
install_db_sec.sql - Installs DTGen's Database Objects' Security
install_usr.sql    - Installs DTGen's User Objects
uninstall_db.sql   - Uninstalls DTGen's Database Objects
uninstall_usr.sql  - Uninstalls DTGen's User Objects
uninstall.sql      - Uninstalls the DTGen Schema Owner. Run as "system" user.
