
prompt
prompt === Remove GUI Helper Units ===

drop view gui_app_tree_vw;
drop package gui_util;

prompt
set define on
