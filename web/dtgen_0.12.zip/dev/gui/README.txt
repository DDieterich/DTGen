
DTGen "dev/gui" README File
   Developed by DMSTEX (http://dmstex.com)


Files and Directories:
----------------------
gui_uncomp.sql   - DTGen GUI Un-Complilation Script
                 Must be updated based on the updated gui_comp.sql script

When "dev" is active, these files will be in place:
---------------------------------------------------
f900.sql            - (Optional) updated F900 APEX GUI Application
gui_app_tree_vw.sql - Updated DTGen View
gui_comp.sql        - Updated DTGen GUI Complilation Script
gui_util.pkb        - Updated DTGen Package
gui_util.pks        - Updated DTGen Package


F900 Update
-----------
To update the F900 APEX GUI Application, see "How to create an application in APEX that uses the generated GUI" in the top-level README.TXT document.


Files Created by "d.sh"
--------------------------
cleanup.log         - Results of the "cleanup" command
load.log            - Results of the "load" command
